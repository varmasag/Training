#!/usr/bin/python

import sys
import requests
user = sys.argv[1]
application = sys.argv[2]
print(user)
url = "https://example.com/users/" + user + "/apps/" + application
page = requests.get(url)
print (page.status_code) 
if page.status_code == 200:
   print("application  " + application + "  for user " + user + "  is healthy")
else:
   print("application  " + application + "  for user " + user + "  is not working")
   



   
   
   
   
   

