#!/usr/bin/env python3

import math
  

def sqrtfn(n) :
    Res = (int)(math.sqrt(n))
    return (Res * Res == n)
  
  

def Pffn(n) :
      
    PR =[True] * (n + 1) 
    p = 2
    while(p * p <= n ):
          
        if (PR[p] == True) :
              

            for i in range(p * 2, n + 1, p) :
                PR[i] = False
                  
        p = p + 1

    for i in range(2, n + 1) :
        if (PR[i] and (sqrtfn(5 * i * i + 4) > 0 or
             sqrtfn(5 * i * i - 4) > 0)) :
            print(i , " ",end="")
  


n = 100
Pffn(n);
  
  

